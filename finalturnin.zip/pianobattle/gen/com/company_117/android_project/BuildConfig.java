/** Automatically generated file. DO NOT MODIFY */
package com.company_117.android_project;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}