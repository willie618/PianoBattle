package com.company_117.android_project;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SongSelection extends Activity{

	public static String song;
	private static final int REQUEST_CODE = 15;
	private static final int SCORE_CODE=13;
	Button b1,b2,b3,b4,b5,bstart;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.song_selection);
		
		// default song - happy birthday
		song = "Happy Birthday";
		
		b1 = (Button) findViewById(R.id.button1);
		b2 = (Button) findViewById(R.id.button2);
		b3 = (Button) findViewById(R.id.button3);
		b4 = (Button) findViewById(R.id.button4);
		b5 = (Button) findViewById(R.id.button5);
		
		
		b1.setBackgroundColor(Color.LTGRAY);
		b2.setBackgroundColor(Color.LTGRAY);
		b3.setBackgroundColor(Color.LTGRAY);
		b4.setBackgroundColor(Color.LTGRAY);
		b5.setBackgroundColor(Color.LTGRAY);
		
		bstart = (Button) findViewById(R.id.button_start);

		// Button 1 - Happy Birthday
		b1.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
	            b1.setBackgroundColor(Color.LTGRAY);
	            b2.setBackgroundColor(Color.DKGRAY);
	            b3.setBackgroundColor(Color.DKGRAY);
	            b4.setBackgroundColor(Color.DKGRAY);
	            b5.setBackgroundColor(Color.DKGRAY);
	            song = "Happy Birthday";
			}
	    });
		
		
		// Button 2 - Jingle Bells
		b2.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
	 			b2.setBackgroundColor(Color.LTGRAY);
	 			b1.setBackgroundColor(Color.DKGRAY);
	 			b3.setBackgroundColor(Color.DKGRAY);
	            b4.setBackgroundColor(Color.DKGRAY);
	            b5.setBackgroundColor(Color.DKGRAY);
	 			song = "Jingle Bells";
			}
	   });
		
	
		// Button 3 - Mary had a little lamb
		b3.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
	            b1.setBackgroundColor(Color.DKGRAY);
	            b2.setBackgroundColor(Color.DKGRAY);
	            b3.setBackgroundColor(Color.LTGRAY);
	            b4.setBackgroundColor(Color.DKGRAY);
	            b5.setBackgroundColor(Color.DKGRAY);
	            song = "Mary Had a Little Lamb";
			}
	    });
		
		// Button 4 - London Bridge
		b4.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
	            b1.setBackgroundColor(Color.DKGRAY);
	            b2.setBackgroundColor(Color.DKGRAY);
	            b3.setBackgroundColor(Color.DKGRAY);
	            b4.setBackgroundColor(Color.LTGRAY);
	            b5.setBackgroundColor(Color.DKGRAY);
	            song = "London Bridge";
			}
	    });
		
		// Button 5 - The Entertainer
		b5.setOnClickListener(new View.OnClickListener()
		{
			public void onClick(View v)
			{
	            b1.setBackgroundColor(Color.DKGRAY);
	            b2.setBackgroundColor(Color.DKGRAY);
	            b3.setBackgroundColor(Color.DKGRAY);
	            b4.setBackgroundColor(Color.DKGRAY);
	            b5.setBackgroundColor(Color.LTGRAY);
	            song = "The Entertainer";
			}
	    });
	}
	
	// Start Button - start the actual game
		public void startGameClick(View view){
			 Intent i= new Intent(this, MainActivity.class);
			 i.putExtra("song_string",song);
			 //i.putExtra("game_mode",0);
			 startActivityForResult(i, REQUEST_CODE);
		}
			
		protected void onActivityResult(int requestCode, int resultCode, Intent data) {
			 
			if (resultCode == RESULT_OK && requestCode == REQUEST_CODE) 
			{ 
				if (data.hasExtra("returnscore"))
				{	
					int score = data.getExtras().getInt("returnscore"); 
					String finalScore = Integer.toString(score); 
			
				
					//Toast.makeText(this, finalScore, Toast.LENGTH_SHORT).show();
					Intent scoreIntent = new Intent(this, ScoreActivity.class);
					scoreIntent.putExtra("singleScore", finalScore); 
					String mode = "single";
					int opponentScore = 5;
					String oppScore = Integer.toString(opponentScore);
					scoreIntent.putExtra("multiScore", oppScore);
					scoreIntent.putExtra("mode", mode);
					startActivityForResult(scoreIntent, SCORE_CODE);
				}
			}
		}
	
	
}
