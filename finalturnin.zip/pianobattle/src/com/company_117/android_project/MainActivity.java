package com.company_117.android_project;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.unity3d.player.UnityPlayerActivity;

public class MainActivity extends UnityPlayerActivity {

	public static int score;
	public static int gameMode;
	public static String song;
	public static String recorded_song;
	public static String received_song;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		score=0;
		gameMode = 0;
		
		Bundle extras = getIntent().getExtras();
		if (extras != null) {
		    song = extras.getString("song_string");
		    gameMode = extras.getInt("game_mode");
		    received_song = extras.getString("record");
		}
		
		//setContentView(R.layout.activity_main);

		/*if (savedInstanceState == null) {
			getSupportFragmentManager().beginTransaction()
					.add(R.id.container, new PlaceholderFragment()).commit();
		}*/
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}


	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
	    super.onKeyDown(keyCode, event);    
	        if(keyCode == KeyEvent.KEYCODE_BACK) {
	            Intent activityC = new Intent(getApplication(), MenuActivity.class);
	            startActivity(activityC);
	            finish();
	            return true;
	        }
	    return super.onKeyUp(keyCode, event);
	}
	/**
	 * A placeholder fragment containing a simple view.
	 */
	public static class PlaceholderFragment extends Fragment {

		public PlaceholderFragment() {
		}

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			return rootView;
		}
	}
	@Override public void finish()
	{ Intent intent = new Intent(); 
	if (gameMode == 1) {
		intent.putExtra("recorded_song", recorded_song); 
		setResult(RESULT_OK, intent); 
		super.finish(); 
	}
	int s = score; 
	intent.putExtra("returnscore", s); 
	
	setResult(RESULT_OK, intent); 
	super.finish(); }
	
	
	public static void setScore(int new_score){
		score=new_score;
	}
	
	public static String getSong() {
		return song;
	}
	
	public static String getRecordedSong() {
		return received_song;
	}
	
	public static void setRecordedSong(String s) {
		recorded_song = new String(s);
	}
	
	public static int getMode() {
		return gameMode;
	}

}
