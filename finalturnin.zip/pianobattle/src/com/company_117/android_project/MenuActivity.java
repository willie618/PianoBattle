package com.company_117.android_project;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class MenuActivity extends Activity{
	private static final int REQUEST_CODE = 15;
	private static final int MULTIPLAYER_CODE = 20;
	private static final int SCORE_CODE=13;
	public static int score;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_menu);
	}
	
	public void singlePlayerClick(View view){
		 Intent i= new Intent(this, SongSelection.class);
		 startActivityForResult(i, REQUEST_CODE);
	}
	
	public void multiPlayerClick(View view){
		 Intent i= new Intent(this, BluetoothChat.class);
		 startActivityForResult(i, MULTIPLAYER_CODE);
	}
	
	
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		 
		if (resultCode == RESULT_OK && requestCode == REQUEST_CODE) 
		{ if (data.hasExtra("returnscore"))
		{ int score = data.getExtras().getInt("returnscore"); 
		String finalScore = Integer.toString(score); 
	
		
		//Toast.makeText(this, finalScore, Toast.LENGTH_SHORT).show();
		Intent scoreIntent = new Intent(this, ScoreActivity.class);
		scoreIntent.putExtra("singleScore", finalScore); 
		String mode = "single";
		int opponentScore = 5;
		String oppScore = Integer.toString(opponentScore);
		scoreIntent.putExtra("multiScore", oppScore);
		scoreIntent.putExtra("mode", mode);
		startActivityForResult(scoreIntent, SCORE_CODE);
		
		}
		}
	}
	
}
