package com.company_117.android_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ScoreActivity extends Activity{

	private TextView mMultiplayerResult;
	private TextView mScoreResult;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		
		super.onCreate(savedInstanceState);
		

		setContentView(R.layout.activity_score);
		
		//get score text views
		mMultiplayerResult = (TextView)findViewById(R.id.textview_multiplayerResult);
		mScoreResult=(TextView)findViewById(R.id.textview_scoreResult);
	
		
		//get score reuslts
		Intent intent = getIntent();
		if(intent != null){
			String single = intent.getStringExtra("singleScore");
			
		String gameMode = intent.getStringExtra("mode");
	//	System.out.print("gameMode is "+gameMode);
			int s= Integer.parseInt(single);
			 ImageView resultPic = (ImageView) findViewById(R.id.gameResult);
			if(gameMode.equals("single")){
			 
				mMultiplayerResult.setText("You achieved a score of " + s);;
				if (s >= 0) {
					resultPic.setImageResource(R.drawable.victory);
				}
				else {
					resultPic.setImageResource(R.drawable.defeat);
				}
			}
			/* if(multi=="NA")
			{
			
				mScoreResult.setText("Your Score is: "+s);
				mMultiplayerResult.setText("Single Player Mode");
	    	
			}
			else if(gameMode=="multi")*/
			else
			{
				String multi = intent.getStringExtra("multiScore");
				
				int m = Integer.parseInt(multi);

				if(s>m)//wins
				{
				mMultiplayerResult.setText("You win with a score of "+s + " to "+m);
				
				resultPic.setImageResource(R.drawable.victory);
				
				}
				else //lose
				{
					mMultiplayerResult.setText("You lost with a score of "+s + " to "+m);
					resultPic.setImageResource(R.drawable.defeat);
					
					
					}
						
					
			}
			}
		}
		
		}
	
	

